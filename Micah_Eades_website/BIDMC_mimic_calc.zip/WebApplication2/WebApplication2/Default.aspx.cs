﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using heartFailure_DetectorNative;
using MathWorks.MATLAB.NET.Arrays;
namespace WebApplication2
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

      
        }

        protected void reset_Click(object sender, EventArgs e)
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "msg", "<scriot language=javascript>clear_inputs();</script>");
            age.Text = string.Empty;
            height.Text = string.Empty;
            weight.Text = string.Empty;
            dia.Text = string.Empty;
            sys.Text = string.Empty;
            heart_rate.Text = string.Empty;
            gender.Text = "Gender";
            prob_result.Text = "?";
        }

        protected void calc_Click(object sender, EventArgs e)
        {
          
            heartFailure_DetectorNative.heartfailure_calculator obj = null;
            obj = new heartFailure_DetectorNative.heartfailure_calculator();

            Double[] inputs = new Double[] {};
            if (age.Text != ""  && gender.Text !="Gender" && height.Text != "" && weight.Text!=""  && dia.Text!="" && sys.Text!="" && heart_rate.Text != "")
            {
                if ((float.Parse(age.Text) > 16) && (float.Parse(height.Text) > 100) && (float.Parse(dia.Text) > 20) && (float.Parse(heart_rate.Text) > 40)) {
                    Double Age = ((Double)float.Parse(age.Text) > 89 ) ? 91.4: ((Double)float.Parse(age.Text)) ;
                    Double Height = (Double)float.Parse(height.Text);
                    Double Weight = (Double)float.Parse(weight.Text);
                    Double Dia = (Double)float.Parse(dia.Text);
                    Double Sys = (Double)float.Parse(sys.Text);
                    Double Hr = (Double)float.Parse(heart_rate.Text);
                    Double Gender = ((gender.Text == "Male") ? 1.0 : 0.0);
                    inputs = new Double[] {Sys,Dia,Height,Weight,Hr,Age,Gender};
                    Double[,] arr = (Double[,])obj.runRFmodel_test(inputs);
                    prob_result.Font.Size = 30;
                    Double rounded_result = Math.Round(arr[0, 0], 4) * 100;
                    prob_result.Text = rounded_result.ToString()+"%";
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Please fill in valid data')</script>");
                }
                
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Please fill in all input fields')</script>");
            }

        }

    }
}